package main

import (
	"database/sql"
	"encoding/json"
	_ "encoding/json"
	"fmt"
	"html/template"
	"log"
	"net/http"

	_ "github.com/denisenkom/go-mssqldb"
	"github.com/gorilla/mux"
	"github.com/olekukonko/tablewriter"
)

type application struct {
	db *sql.DB
}

type Customer struct {
	Customer_id  string `json:"customer_id"`
	NameStyle    string `json:"Name_Style"`
	Title        string `json:"title"`
	FirstName    string `json:"firstname"`
	MiddleName   string `json:"middlename"`
	LastName     string `json:"lastname"`
	Suffix       string `json:"suffix"`
	CompanyName  string `json:"companyname"`
	SalesPerson  string `json:"salesperson`
	EmailAddress string `json:"emailaddress`
	Phone        string `json:"phone`
	PasswordHash string `json:"passwordhash"`
	PasswordSalt string `json:"passwordsalt`
	RowGuide     string `json:"rowguide`
	ModifiedDate string `json:"modifieddate`
}

func setup() (*sql.DB, error) {
	const (
		server   = "jan2bootcampserver.database.windows.net"
		user_id  = "bootcamp"
		password = "Pass@123"
		dbName   = "Jan2bootcampdatabase"
	)
	connString := fmt.Sprintf("server=%s;user id=%s;password=%s;database=%s", server, user_id, password, dbName)

	db, err := sql.Open("sqlserver", connString)

	if err != nil {
		log.Fatal("Error opening database:", err.Error())
	}

	// Test the connection
	err = db.Ping()
	if err != nil {
		log.Fatal("Error connecting to the database:", err.Error())
	}

	fmt.Println("Connected to the SQL Server database!")

	return db, nil

}

func main() {

	db, err := setup()

	if err != nil {
		log.Fatal(err)
	}

	app := &application{
		db: db,
	}

	r := mux.NewRouter()

	r.HandleFunc("/home", app.homeHandler).Methods("GET")
	r.HandleFunc("/customer", app.sample).Methods("GET")
	log.Fatal(http.ListenAndServe(":4000", r))

}

func (app *application) homeHandler(w http.ResponseWriter, r *http.Request) {
	tmp, err := template.ParseFiles("./ui/index.html")

	if err != nil {
		http.Error(w, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}

	err = tmp.Execute(w, nil)

	if err != nil {
		http.Error(w, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}

}

func (app *application) sample(w http.ResponseWriter, r *http.Request) {
	// Sample data
	w.Header().Set("Content-Type", "application/json")

	rows, err := app.db.Query("SELECT TOP 20 * FROM SalesLT.Customer")
	if err != nil {
		log.Fatal("Error executing query:", err.Error())
	}
	defer rows.Close()

	var AllCustomers []Customer

	// Process the result set
	for rows.Next() {
		// Process each row as needed

		var customer Customer

		var CustomerID sql.NullString
		var NameStyle sql.NullString

		var Title sql.NullString
		var FirstName sql.NullString
		var MiddleName sql.NullString
		var LastName sql.NullString
		var Suffix sql.NullString
		var CompanyName sql.NullString
		var SalesPerson sql.NullString
		var EmailAddress sql.NullString
		var Phone sql.NullString
		var PasswordHash sql.NullString
		var PasswordSalt sql.NullString
		var RowGuide []byte
		var ModifiedDate sql.NullString

		err := rows.Scan(&CustomerID, &NameStyle, &Title, &FirstName, &MiddleName, &LastName, &Suffix, &CompanyName, &SalesPerson, &EmailAddress, &Phone, &PasswordHash, &PasswordSalt, &RowGuide, &ModifiedDate)
		if err != nil {
			log.Fatal("Error scanning row:", err.Error())
		}

		if CustomerID.Valid {
			customer.Customer_id = CustomerID.String
		} else {
			customer.Customer_id = "NULL"
		}
		if NameStyle.Valid {
			customer.NameStyle = NameStyle.String
		} else {
			customer.NameStyle = "NULL"
		}
		if Title.Valid {
			customer.Title = Title.String
		} else {
			customer.Title = "NULL"
		}
		if FirstName.Valid {
			customer.FirstName = FirstName.String
		} else {
			customer.FirstName = "NULL"
		}
		if MiddleName.Valid {
			customer.MiddleName = MiddleName.String
		} else {
			customer.MiddleName = "NULL"
		}
		if LastName.Valid {
			customer.LastName = LastName.String
		} else {
			customer.LastName = "NULL"
		}
		if Suffix.Valid {
			customer.Suffix = Suffix.String
		} else {
			customer.Suffix = "NULL"
		}
		if CompanyName.Valid {
			customer.CompanyName = CompanyName.String
		} else {
			customer.CompanyName = "NULL"
		}
		if SalesPerson.Valid {
			customer.SalesPerson = SalesPerson.String
		} else {
			customer.SalesPerson = "NULL"
		}
		if EmailAddress.Valid {
			customer.EmailAddress = EmailAddress.String
		} else {
			customer.EmailAddress = "NULL"
		}
		if Phone.Valid {
			customer.Phone = Phone.String
		} else {
			customer.Phone = "NULL"
		}
		if PasswordHash.Valid {
			customer.PasswordHash = PasswordHash.String
		} else {
			customer.PasswordHash = "NULL"
		}
		if PasswordSalt.Valid {
			customer.PasswordSalt = PasswordHash.String
		} else {
			customer.PasswordSalt = "NULL"
		}
		// if RowGuide.Valid {
		// 	customer.RowGuide = RowGuide.String
		// }else{
		// 	customer.RowGuide = "NULL"
		// }
		if ModifiedDate.Valid {
			customer.ModifiedDate = ModifiedDate.String
		} else {
			customer.ModifiedDate = "NULL"
		}
		customer.RowGuide = string(RowGuide)
		AllCustomers = append(AllCustomers, customer)

	}

	u,err := json.Marshal(AllCustomers);

	if err!=nil {
		log.Fatal(err.Error())
	}

	fmt.Println(u)

// 	// Create a new table
// 	table := tablewriter.NewWriter(w)

// 	// Set table header
// 	table.SetHeader([]string{"CustomerID", "NameStyle", "Title", "FirstName", "MiddleName", "LastName", "Suffix", "CompanyName", "SalesPerson", "EmailAddress", "Phone", "ModifiedDate"})

// 	// Add data to the table
// 	for _, d := range AllCustomers {
// 		table.Append([]string{d.CompanyName, d.NameStyle, d.Title, d.FirstName, d.MiddleName, d.LastName, d.Suffix, d.CompanyName, d.SalesPerson, d.EmailAddress, d.Phone, d.ModifiedDate})
// 	}

// // 	// Render the table as HTML
// 	table.Render()

}
